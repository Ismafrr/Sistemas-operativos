
/**************************************************************************
	Fecha; 20/02/2025
	Autor: Santiago Forero Romero
	Pontificia Universidad Javeriana
	Meteria: Sistemas Operativos
	Tema: Memoria Dinamica, Modularidad, Documentacion
	Funciones
*******************************+******************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "modulo.h"

// Función para inicializar una matriz con valores específicos
void inicializarMatriz(int *matriz, int N, int tipo) {
    for (int i = 0; i < N * N; i++) {
        if (tipo == 1) {
            matriz[i] = i * 2; // Inicialización para Matriz A
        } else if (tipo == 2) {
            matriz[i] = i * 3 + i; // Inicialización para Matriz B
        } else {
            matriz[i] = 0; // Inicialización para Matriz C (vacía)
        }
    }
}

// Función para multiplicar dos matrices y almacenar el resultado en una tercera matriz
void multiplicarMatriz(int *mA, int *mB, int *mC, int N) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int sum = 0;
            for (int k = 0; k < N; k++) {
                sum += mA[i * N + k] * mB[k * N + j];
            }
            mC[i * N + j] = sum;
        }
    }
}

// Función para medir el tiempo de ejecución de la multiplicación de matrices
double calcularTiempoEjecucion(int *mA, int *mB, int *mC, int N) {
    clock_t inicio, fin;
    double tiempo_ejecucion;

    inicio = clock(); // Capturar tiempo de inicio
    multiplicarMatriz(mA, mB, mC, N);
    fin = clock(); // Capturar tiempo de finalización

    tiempo_ejecucion = ((double)(fin - inicio)) / CLOCKS_PER_SEC;
    return tiempo_ejecucion;
}

// Función para liberar la memoria de las matrices
void liberarMemoria(int *mA, int *mB, int *mC) {
    free(mA);
    free(mB);
    free(mC);
}
