#ifndef __MODULO_H_
#define __MODULO_H_


/**************************************************************************
	Fecha; 20/02/2025
	Autor: Santiago Forero Romero
	Pontificia Universidad Javeriana
	Meteria: Sistemas Operativos
	Tema: Memoria Dinamica, Modularidad, Documentacion
		INTERFAZ DE FUNCIONES: BIBLIOTECA
*******************************+******************************************/


// Función para inicializar una matriz con valores específicos
void inicializarMatriz(int *matriz, int N, int tipo);

// Función para imprimir una matriz
void imprimirMatriz(int *matriz, int N, char nombre);

// Función para multiplicar dos matrices y almacenar el resultado en una tercera matriz
void multiplicarMatriz(int *mA, int *mB, int *mC, int N);

// Función para medir el tiempo de ejecución de la multiplicación de matrices
double calcularTiempoEjecucion(int *mA, int *mB, int *mC, int N);

// Función para liberar la memoria de las matrices
void liberarMemoria(int *mA, int *mB, int *mC);

#endif
