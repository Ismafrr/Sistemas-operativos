
/**************************************************************************
	Fecha; 20/02/2025
	Autor: Santiago Forero Romero
	Pontificia Universidad Javeriana
	Meteria: Sistemas Operativos
	Tema: Memoria Dinamica, Modularidad, Documentacion
		Programa principal
*******************************+******************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "modulo.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Uso: %s <tamaño de la matriz>\n", argv[0]);
        return 1;
    }

    // Obtener el tamaño de la matriz desde los argumentos
    int N = atoi(argv[1]);

    if (N <= 0) {
        printf("El tamaño de la matriz debe ser un número entero positivo.\n");
        return 1;
    }

    /* Crear punteros de memoria para las matrices */
    int *mA = (int *)malloc(sizeof(int) * N * N);
    int *mB = (int *)malloc(sizeof(int) * N * N);
    int *mC = (int *)malloc(sizeof(int) * N * N);

    if (mA == NULL || mB == NULL || mC == NULL) {
        printf("Error al asignar memoria.\n");
        return 1;
    }

    // Inicializar las matrices
    inicializarMatriz(mA, N, 1);
    inicializarMatriz(mB, N, 2);
    inicializarMatriz(mC, N, 3);

    // Calcular el tiempo de ejecución de la multiplicación
    double tiempo = calcularTiempoEjecucion(mA, mB, mC, N);

    // Imprimir solo el tiempo de ejecución
    printf("Tiempo de ejecución para una matriz de tamaño %dx%d: %.6f segundos\n", N, N, tiempo);

    // Liberar memoria
    liberarMemoria(mA, mB, mC);

    return 0;
}
